<?php
if ( !class_exists( "conectabd" ) ) 
{ 
	class conectabd
	{
		var $db_user;
		var $db_pass;
		var $db_host;	
		var $db_name;
		function asignabd()
		{
	//Pruebas en el tres
			$this->db_user = 'root';
			$this->db_pass = 'root';
			$this->db_host = 'localhost';
			//$this->db_name = 'softjic_lapremier';
			$this->db_name = 'softjitc_lapremier';' 
  		}

 	}
}
?>
